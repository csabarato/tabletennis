package com.csabarato.tabletennis.repository;

import com.csabarato.tabletennis.model.Competition;
import org.springframework.data.repository.CrudRepository;

public interface CompetitionRepository extends CrudRepository<Competition, Integer> {


}
